//
//  Constant.swift
//  FuXiWeather
//
//  Created by 刘军 on 2021/6/6.
//

import Foundation

let kQWeatherWebKey = "a4db9fabfad9419c94ee8718efb0820a"

let kQWeatherNowPath = "https://devapi.qweather.com/v7/weather/now"

let kQWeatherCityPath = "https://geoapi.qweather.com/v2/city/lookup"
