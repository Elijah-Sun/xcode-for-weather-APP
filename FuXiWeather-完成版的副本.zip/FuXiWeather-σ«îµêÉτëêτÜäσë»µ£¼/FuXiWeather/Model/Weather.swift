//
//  Weather.swift
//  FuXiWeather
//
//  Created by 刘军 on 2021/5/31.
//

import Foundation

class Weather{
    var temp = ""
    var icon = ""
    var city = ""
}
