import UIKit

var arr = ["aa", "bb", "cc"]
var dict: [String: Any] = ["name": "张三", "age": 20, "gender": "男"]

arr[0]
dict["name"]
//key - value 键值对


